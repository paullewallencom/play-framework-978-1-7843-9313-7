from my_app import app as application
import sys, logging
logging.basicConfig(stream = sys.stderr)
