from my_app import app
app.env="development"
app.run(debug=True)
