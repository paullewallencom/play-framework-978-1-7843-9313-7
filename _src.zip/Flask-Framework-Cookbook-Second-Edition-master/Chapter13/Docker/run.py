from my_app import app
app.run(debug=True, host='0.0.0.0')
